const $ = id => document.getElementById(id);
async function refresh(){
  const crop=$("crop").value, qty=Math.max(1,Number($("qty").value)||1);
  const [p,m,b]=await Promise.all([
    fetch(`/api/predict?crop=${encodeURIComponent(crop)}&quantity=${qty}`).then(r=>r.json()),
    fetch(`/api/markets?crop=${encodeURIComponent(crop)}`).then(r=>r.json()),
    fetch(`/api/buyers?crop=${encodeURIComponent(crop)}&quantity=${qty}`).then(r=>r.json())
  ]);
  $("prediction").innerHTML=`<b>Indicative estimate: ₹${p.indicative_estimate}/kg</b><br>Reference average: ₹${p.current_reference_price}/kg · Estimated gross value: ₹${p.estimated_gross_value.toLocaleString("en-IN")}<br><small>${p.method}. ${p.notice}</small>`;
  $("marketRows").innerHTML=m.markets.map((x,i)=>`<tr><td><b>${x.market}</b></td><td>₹${x.price}/kg</td><td>${x.distance_km} km</td><td>${i===0?"Nearby reference":x.price===Math.max(...m.markets.map(y=>y.price))?"Higher listed price — check freight":"Compare transport and handling"}</td></tr>`).join("");
  $("buyerRows").innerHTML=b.buyers.length?b.buyers.map(x=>`<article class="buyer"><strong>${x.name}</strong><p>${x.tag} · ${x.city}</p><p>Crop: ${x.crop} · Capacity: ${x.quantity} kg</p><b>Sample offer: ₹${x.offer}/kg</b><p>Demo rating: ${x.rating}/5</p></article>`).join(""):"<p>No sample buyer matches for this crop and quantity. Try a smaller quantity or another crop.</p>";
}
$("refresh").addEventListener("click",refresh);$("crop").addEventListener("change",refresh);refresh();
